function res = solvepdeeigtest(self, evalinterval)

coefstruct = self.EquationCoefficients.packCoefficients();

% Ignore forcing when solving eigenvalue problem.
% Assign appropriate sized zeros to f-coefficient so that global F is not
% computed in calls to built-in functions.
for sd = 1:length(coefstruct.Coefficients.c) %Assign zeros for all subdomains
    coefstruct.Coefficients.f{sd} = zeros(self.PDESystemSize,1);
end

% Compute BC matrices.
[p,e,t] = self.Mesh.meshToPet();

u0 = pdeuxpd(p,0,self.PDESystemSize);
tdummy = 0:0.1:1;
femodel = pde.DynamicDiscretizedPDEModel(self,p,e,t,coefstruct,u0,tdummy,self.EquationCoefficients.mDefined());

if (femodel.IsSpatialCoefficientsNonlinear || femodel.vd)
    error(message('pde:pdeModel:coefsNonlinear'))
end

K = femodel.K;
A = femodel.A;
Q = femodel.Q;
H = femodel.H;
M = femodel.Mass;

% Impose BC.
[null,~]=pdenullorth(H);
KK=K+Q+A;
K=null'*KK*null;
B = null;
M = B'*M*B;

% Make nearly symmetric matrices exactly symmetric
K = self.checkForSymmetry(K);
M = self.checkForSymmetry(M);

if (issymmetric(K) && issymmetric(M))
    % Convert problems with negative semidefinite mass
    if sum(diag(M)) < 0
        K = -K;
        M = -M;
    end
    opts.FrequencyRange = [evalinterval(1),evalinterval(2)];
    [v,l] = matlab.internal.math.lanczos(sparse(K),sparse(M),opts);
    ires = 0;
else
    % Positive definite is checked inside sptarn
    spd=0;
    [v,l,ires]=sptarn(K,M,evalinterval(1),evalinterval(2),spd, 'Stats', 'on');
end



if ires<0
    error(message('pde:pdeModel:MoreEigenvaluesMayExist'));
end

if ~isempty(v)
    v=B*v;
end

if isempty(l)
    res = pde.EigenResults;
else
    res = pde.EigenResults(self,v,l);
end

end
