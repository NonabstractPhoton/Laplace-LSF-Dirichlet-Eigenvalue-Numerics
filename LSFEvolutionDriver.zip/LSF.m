%{
    This object represents a discretized Level Set Function
%}

classdef LSF
    properties
        
        % i,j -> (y, x)
        coordinateGrid {mustBeNumeric}
        
        % phi(i,j)
        values {mustBeNumeric}
        backwardGradients {mustBeNumeric}
        forwardGradients {mustBeNumeric}
        contour {mustBeNumeric}
        
        % dilation from [-1,1] x [-1, 1] to coordinate space
        % coordinateDilation = max(|x|) = max(|y|) 
        % helps define isomorphism coordinate space -> grid space
        coordinateDilation {mustBeNumeric} = 1

        p {mustBeNumeric} = 20

    end

    methods

        function obj = LSF(initialValues, dilation)
                        
            n = size(initialValues,1);
            assert(n == size(initialValues,2));

            obj.values = initialValues;
            obj.coordinateDilation = dilation;
    
            [i,j] = meshgrid(1:n);
            [x,y] = obj.gridToCoordinates(i,j);
            obj.coordinateGrid = cat(3,x,y);

        end

        function phi = interpolate(obj, coordinates)
            coordinateList = reshape(obj.coordinateGrid, [], 2);
            phi = griddata(coordinateList(1,:), coordinateList(2,:), obj.values(:), coordinates(1,:), coordinates(2,:));
        end

        % returns gridded points closest to 0 level set contour
        function obj = computeContour(obj)          
            
            obj.contour = contourc(obj.values, [0,0]);
            obj.contour(:,1) = [];
            obj.contour = rmoutliers( ...
                unique(obj.contour', 'rows') ...
                , "percentiles", [5,95]);
            [obj.contour(:,1), obj.contour(:,2)] = obj.gridToCoordinates(obj.contour(:,1), obj.contour(:,2));
        end
        
        % Creates a mesh for the PDEmodel with the provided function
        % Recomputes contour and interior points each time
        % Modifies the object, so capture the return
        function obj = updateMesh(obj, model, generateMeshFunction)
            n = size(obj.values,1);
            obj = obj.computeContour();
            boundedPoints = unique(cat(1,obj.contour, reshape((obj.values <= 0) .* obj.coordinateGrid, n^2,2)), "rows");           
            shp = alphaShape(boundedPoints, "HoleThreshold",.025^2, "RegionThreshold",.04^2);
            
            model.Geometry = [];
            geometryFromMesh(model, shp.Points', shp.alphaTriangulation()');
            generateMeshFunction(model);
        end

        function obj = updateMeshStrict(obj, model, generateMeshFunction)
            n = size(obj.values,1);
            interiorPoints = unique(reshape((obj.values <= 0) .* obj.coordinateGrid, n^2,2), "rows");           
            shp = alphaShape(interiorPoints, "HoleThreshold",.025^2, "RegionThreshold",.04^2);
            
            model.Geometry = [];
            geometryFromMesh(model, shp.Points', shp.alphaTriangulation()');
            generateMeshFunction(model);
        end

        % uses ENO
        % only run after updating LSF values, memory expensive
        function obj = computeGradients(obj)

            n = size(obj.values(),1);

            % square grid so arbitrary choice
            gridDelta = obj.coordinateGrid(1,2,1) - obj.coordinateGrid(1,1,1);
            

            forwardDiffx = [diff(obj.values,1,2)] / gridDelta;
            backwardDiffx = [zeros(n,1) forwardDiffx];
            forwardDiffx = [forwardDiffx zeros(n,1)];
            
            forwardDiffy = [-diff(obj.values,1)] / gridDelta;
            backwardDiffy = [forwardDiffy; zeros(1,n)];
            forwardDiffy = [zeros(1,n); forwardDiffy];
            
            obj.forwardGradients = zeros(n,n, 2);
            obj.backwardGradients = obj.forwardGradients;
            obj.forwardGradients = LSF.getWENOGradient(forwardDiffx, forwardDiffy);
            obj.backwardGradients = LSF.getWENOGradient(backwardDiffx, backwardDiffy);
        end

        % The algorithms below are adapted from Distance Regularized Level Set Evolution and Its Application to Image Segmentation by Li et al.
        % Note gradients are WENO but divergence and laplace are inbuilts using central diff and finite diff respectively. 
        % These are numerically stable for DRLSE according to the cited paper.
        function obj = DRLSE(obj, eigenResults, model, k, gamma, meshGenerator,J)
           
            obj = obj.reinitialize();
            obj = obj.computeContour();
            % obj = obj.NeumannBoundCond();
            obj = obj.computeGradients();
            
            [V, narrowband] = obj.getDeformationField(model,eigenResults, k, gamma);

            gradients = (V <= 0).* obj.forwardGradients + (V > 0) .* obj.backwardGradients;
            s = sqrt(gradients(:, :, 1).^2 + gradients(:, :, 2).^2);

            distRegTerm = distRegP2(obj, gradients, s);

            % add armijo wolfe linsearch for timestep
,
            % timestep = 1/max(abs(V),[],"all");
            timestep = obj.armijoWolfeLinesearch(V, s, eigenResults, model, k, gamma, meshGenerator, J);
            mu = 0;

            obj.values = obj.values + timestep * (mu*distRegTerm.*narrowband - V.*s);

            obj = obj.updateMesh(model, meshGenerator);
        end

        function [V, narrowband] = getDeformationField(obj, model,eigenResults, k, gamma)
                    
            n = size(obj.values, 1);
            
            centralGrad = (obj.forwardGradients + obj.backwardGradients) ./ 2;
            centralGrad(:, 1, 1) = obj.forwardGradients(:, 1, 1);
            centralGrad(:, end, 1) = obj.backwardGradients(:, end, 1);
            centralGrad(1, :, 2) = obj.backwardGradients(1, :, 2);
            centralGrad(end, :, 2) = obj.forwardGradients(end, :, 2);

            magntidues = sqrt(centralGrad(:, :, 1).^2 + centralGrad(:, :, 2).^2);

            % avoid / by 0
            N = centralGrad ./ (magntidues + (magntidues == 0) * eps(0));

            % Get linear indices closest to boundary
            interior = obj.values <= 0; 
            cI = obj.contour;
            [cI(:,1), cI(:,2)] = obj.coordinatesToGrid(cI(:,1), cI(:,2));

            % Select narrowband as every neighboring point of boundary
            cn = size(cI,1);
            col10 = [ones(cn,1), zeros(cn,1)];
            col01 = [zeros(cn,1),ones(cn,1)];
            cI = rmoutliers(unique(cat(1,cI,cI+1,cI-1,cI+col10, cI-col10,cI+col01,cI-col01),"rows"),"percentiles", [20,80]);
            cI = sub2ind([n n], cI(:,1), cI(:,2));
            
            narrowband = zeros(n);
            narrowband(cI) = 1;
            I = find(narrowband & interior);
            X = obj.coordinateGrid(:,:,1);
            Y = obj.coordinateGrid(:,:,2);

            % Evaluate eigenfunction gradients on interior narrowband
            psi = InterpolateEigenGradient(model,eigenResults.Eigenvectors(:,k),[X(I), Y(I)]);
            psix = psi(:,1);
            psiy = psi(:,2);
            psix(isnan(psix)) = 0;
            psiy(isnan(psiy)) = 0;
            fullpsix = zeros(n);
            fullpsix(I) = psix;
            fullpsiy = zeros(n);
            fullpsiy(I) = psiy;
            gradpsik = cat(3,fullpsix,fullpsiy);

            [psix, psiy] = InterpolateEigenGradient(model,eigenResults.Eigenvectors(:,k+1),[X(I), Y(I)]);
            psix(isnan(psix)) = 0;
            psiy(isnan(psiy)) = 0;
            fullpsix = zeros(n);
            fullpsix(I) = psix;
            fullpsiy = zeros(n);
            fullpsiy(I) = psiy;
            gradpsik1 = cat(3,fullpsix,fullpsiy);
            
            p = obj.p;
            lk = eigenResults.Eigenvalues(k);
            lk1 = eigenResults.Eigenvalues(k+1);

            % Boundary deformation speed given by
            
            %{
                Vn(x) = |Ω| ((1 − γ)|∂nψk|^2 + (
                                γ((λk)^p+(λk+1)^p)^((1/p-1)) (
                                    (λk)^(p-1)|∂nψk|^2 + (λk+1)^(p-1)|∂nψk+1|^2
                            )
                        - ( (1 − γ)λk + γ((λk)^p + (λk+1)^p)^1/p ) 
            %}
            
            V = eigenResults.Mesh.area * ((1-gamma)*dot(gradpsik,N,3).^2 + ( ...
                gamma*(lk^p + lk1^p)^(1/p - 1) * ( ...
                    (lk^(p-1))*dot(gradpsik,N,3).^2 + (lk1^(p-1))*dot(gradpsik1,N,3).^2 ...
                    )...
                )) - ((1-gamma)*lk + gamma*((lk^p + lk1^p)^(1/p)));

            %{
            V = eigenResults.Mesh.area * ((1-gamma) * dot(gradpsik, N, 3).^2 + gamma*dot(gradpsik1, N, 3).^2) ...
                - ((1-gamma)*eigenResults.Eigenvalues(k) + gamma * eigenResults.Eigenvalues(k+1));
            %}

            % Above calculation only valid for interior narrowband and
            % boundary
            V = (narrowband & interior) .* V;
            
            % Compute closest "boundary" points, grid boundary may not
            % align with domain boundary so those also need extending
            [~, ind] = bwdist(narrowband & interior);           
            
            % Extend deformation field to exterior narrowband and grid
            % boundary
            V = V + ((narrowband & ~interior)  .* V(ind));
        end

        function distRegTerm = distRegP2(obj, gradients, s)

            % square grid so arbitrary choice
            gridDelta = obj.coordinateGrid(1,2,1) - obj.coordinateGrid(1,1,1);

            a=(s>=0) & (s<=1);
            b=(s>1);
            ps=a.*sin(2*pi*s)/(2*pi)+b.*(s-1);  
            dps=((ps~=0).*ps+(ps==0))./((s~=0).*s+(s==0));
            
            distRegTerm = LSF.div( ...
                dps.*gradients(:, :, 1) - gradients(:, :, 1), ...
                dps.*gradients(:, :, 2) - gradients(:, :, 2), ...
                gridDelta ...
                ) + 4*del2(obj.values, gridDelta);  
        end

        function obj = reinitialize(obj)
            n = size(obj.values,1);
            cI = rmoutliers(unique(round(obj.contour * n/2), "rows"), "percentile", [20,80]);
            cI(:,1) = cI(:,1) + n/2;
            cI(:,2) =  n/2 - cI(:,2);
            sign = ones(n) - 2 * (obj.values <= 0);
            obj.values = sign .* msfm2d(ones(size(obj.values)),cI',true,true);
        end

        function [x,y] = gridToCoordinates(obj,i,j)
            n = size(obj.values,1);
            x = (i - n/2) * 2/n * obj.coordinateDilation;
            y = (n/2 - j) * 2/n * obj.coordinateDilation;
        end

        function [i,j] = coordinatesToGrid(obj,x,y)
            n = size(obj.values,1);
            i = round(x*(n/2)/obj.coordinateDilation + n/2);
            j = round(n/2 - y * (n/2)/obj.coordinateDilation); 
        end


        function obj = NeumannBoundCond(obj)
            n = size(obj.values, 1);
            obj.values([1 n],[1 n]) = obj.values([3 n-2],[3 n-2]);  
            obj.values([1 n],2:end-1) = obj.values([3 n-2],2:end-1);          
            obj.values(2:end-1,[1 n]) = obj.values(2:end-1,[3 n-2]);  
        end

        % Performs a linesearch with Armijo-Wolfe 
        function alpha = armijoWolfeLinesearch(obj, V, s, eigenResults, model, k, gamma, meshGenerator, J)
            m = 3;
            c1 = 10^-4;
            c2 = .9;
            p = obj.p;

            maxV = max(abs(V),[],"all");
            alphaBase = 1/maxV;
            alpha = alphaBase;
            return;
            alphas = alphaBase * 2.^(-m:m) + rand(1,2*m+1)/maxV;
            costs = J * ones(1,2*m+1);
            parfor i=1:numel(alphas)
                tempLSF = obj;
                tempLSF.values = tempLSF.values + alphas(i) * (-V.*s);
                tempModel = model;
                tempLSF.updateMesh(tempModel, meshGenerator);
                tempResults = LDEigSolver(tempModel, [0,20*(k+1)],k);
                costs(i) = (1-gamma)*tempModel.Mesh.area*tempResults.Eigenvalues(k) ...
                    + gamma*tempModel.Mesh.area*(tempResults.Eigenvalues(k)^p + tempResults.Eigenvalues(k+1)^p)^(1/p);
            end

            min = costs(1);
            alpha = alphas(1);
            for i=2:numel(costs)
                if (costs(i) <= min)
                    min = costs(i);
                    alpha = alphas(i);
                end
            end
            
        end
    end
    
    methods(Static)

        function val = indexInterpolate(arr,t)
            val = arr(floor(t)) + (t-floor(t))*(arr(ceil(t))-arr(floor(t)))
        end

        function gradient = getWENOGradient(diffx, diffy)
            
            % Optimal WENO weights for smooth regions
            w = [.1, .6, .3];
            n = size(diffx,1);

            % example for v1fx
            % dx1 dx2 dx3 dx4 dx5 ->  0 0 dx1 dx2 dx3 
            v1 = cat(3, [zeros(n,2) diffx(:, 1:n-2)], [diffy(3:n, :); zeros(2,n)]);
            v2 = cat(3, [zeros(n,1), diffx(:, 1:n-1)], [diffy(2:n, :); zeros(1,n)]);
            v3 = cat(3, diffx, diffy);
            v4 = cat(3, [diffx(:, 2:n) zeros(n,1)], [zeros(1, n); diffy(1:n-1, :)]);
            v5 = cat(3, [diffx(:, 3:n), zeros(n,2)], [zeros(2,n); diffy(1:n-2, :)]);

            % see page 34 of Level Set Methods Osher Fedkiw
        
            ENO1 = (v1/3 - 7/6 * v2 + 11/6 * v3);
            ENO2 = (-1/6 * v2 + 5/6 * v3 + v4/3);
            ENO3 = (v3/3 + 5/6 * v4 - v5/6);

            gradient = w(1) * ENO1 + w(2) * ENO2 + w(3) * ENO3;

            % Appropriate ENO for edge
            % gx
            gradient(:, 1, 1) = ENO3(:, 1, 1);
            gradient(:, end, 1) = ENO1(:, end, 1);
            % gy
            gradient(1, :, 2) = ENO1(1, :, 2);
            gradient(end, :, 2) = ENO3(end, :, 2);

        end

        function f = div(nx,ny, delta)
            [nxx,~]=gradient(nx, delta);  
            [~,nyy]=gradient(ny, delta);
            f=nxx+nyy;
        end
    end
end